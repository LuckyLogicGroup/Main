pip install -r requirements.txt

flask initdb


python app.py
 
 
 
  Current Logins
User: alex1 / alex234

Admin: theadmin / admin2345